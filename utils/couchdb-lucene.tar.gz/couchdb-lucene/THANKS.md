* Thanks to Paul Davis for contributing the enhanced Javascript indexing API.
* Thanks to Adam Lofts for the performance boosting JSONDocumentAdapter et al.
* Thanks to Santiago M. Mola for the termvector option.
* Thanks to Joe Hillenbrand for adding default result limit to config.
* Thanks to Nate Steffen for adding highlighting.
