// Copyright (C) TOSHIBA CORPORATION, 2023. Part of the SW360 Frontend Project.
// Copyright (C) Toshiba Software Development (Vietnam) Co., Ltd., 2023. Part of the SW360 Frontend Project.
// Copyright (C) Siemens AG, 2025. Part of the SW360 Frontend Project.

// This program and the accompanying materials are made
// available under the terms of the Eclipse Public License 2.0
// which is available at https://www.eclipse.org/legal/epl-2.0/

// SPDX-License-Identifier: EPL-2.0
// License-Filename: LICENSE

'use client'

import { useTranslations } from 'next-intl'
import { ReactNode, useEffect, useState } from 'react'
import Button from 'react-bootstrap/Button'
import Modal from 'react-bootstrap/Modal'
import { FaInfoCircle } from 'react-icons/fa'

import { CommonUtils } from '@/utils'
import { signOut, useSession } from 'next-auth/react'
import styles from '../detail.module.css'

interface Props {
    licenseInfo: { [key: string]: string | Array<string> | number }
    isISR: boolean
    attachmentName?: string
}

const SPDXLicenseView = ({ licenseInfo, isISR, attachmentName }: Props): ReactNode => {
    const t = useTranslations('default')
    const [selectedLicenseId, setSelectedLicenseId] = useState<string>()
    const [modalShow, setModalShow] = useState(false)
    const { status } = useSession()

    useEffect(() => {
        if (status === 'unauthenticated') {
            signOut()
        }
    }, [status])

    const handleCloseDialog = () => {
        setModalShow(false)
    }

    const caculateComplexity = (totalFileCount: number) => {
        if (totalFileCount <= 1000) {
            return 'small'
        }

        if (totalFileCount > 1000 && totalFileCount <= 5000) {
            return 'medium'
        }

        return 'large'
    }

    const renderLicenseIds = (licenseIds: Array<string>) => {
        return licenseIds.map((licenseId) => (
            <li key={licenseId}>
                {licenseId}
                {isISR && (
                    <FaInfoCircle
                        onClick={() => showLicenseToSrcMapping(licenseId)}
                        style={{ marginLeft: '5px', color: 'gray' }}
                        className={styles.info}
                    />
                )}
            </li>
        ))
    }

    const showLicenseToSrcMapping = (licenseId: string) => {
        setSelectedLicenseId(licenseId)
        setModalShow(true)
    }

    const renderSourceList = (sourceList: Array<string>) => {
        return sourceList.map((source) => <li key={source}>{source}</li>)
    }

    return (
        <div>
            {isISR && (
                <>
                    <div>
                        {t('Total Number Of Files')}: <b>{licenseInfo['totalFileCount']}</b>
                    </div>
                    <div>
                        {t('Complexity')}: <b>{caculateComplexity(licenseInfo.totalFileCount as number)}</b> (
                        {t('based on license file count')})
                    </div>
                </>
            )}
            {CommonUtils.isNullEmptyOrUndefinedArray(licenseInfo['licenseIds'] as Array<unknown>) ? (
                <>
                    <div>
                        <b>{t('conclude_license_id')}:</b>
                        <br /> N/A
                    </div>
                </>
            ) : (
                <>
                    <div>
                        <b>{licenseInfo.license}</b>
                    </div>
                    <ul>{renderLicenseIds(licenseInfo['licenseIds'] as Array<string>)}</ul>
                </>
            )}
            {CommonUtils.isNullEmptyOrUndefinedArray(licenseInfo['otherLicenseIds'] as Array<string>) ? (
                <>
                    <div>
                        <b>{t('Other License Ids')}:</b>
                        <br /> N/A
                    </div>
                </>
            ) : (
                <>
                    <div>
                        <b>{t(licenseInfo.otherLicense as never)}</b>
                    </div>
                    <ul>{renderLicenseIds(licenseInfo['otherLicenseIds'] as Array<string>)}</ul>
                </>
            )}

            <Modal
                show={modalShow}
                onHide={handleCloseDialog}
                backdrop='static'
                centered
                size='lg'
            >
                <Modal.Header
                    closeButton
                    style={{ color: '#2e5aac' }}
                >
                    <Modal.Title>
                        <b>{attachmentName}</b>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {!CommonUtils.isNullEmptyOrUndefinedString(selectedLicenseId) && (
                        <>
                            <div>
                                {t('License Name')}: <b>{selectedLicenseId}</b>
                            </div>
                            <div>
                                {t('Source File List')}:
                                <ul>
                                    {CommonUtils.isNullEmptyOrUndefinedArray(
                                        licenseInfo[selectedLicenseId] as Array<string>,
                                    ) ? (
                                        <li>{t('Source file information not found in ISR')}</li>
                                    ) : (
                                        renderSourceList(licenseInfo[selectedLicenseId] as Array<string>)
                                    )}
                                </ul>
                            </div>
                        </>
                    )}
                </Modal.Body>
                <Modal.Footer className='justify-content-end'>
                    <Button
                        variant='light'
                        onClick={handleCloseDialog}
                    >
                        {' '}
                        OK{' '}
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default SPDXLicenseView
